### Balloon castle wars path
![Balloon_castle_wars_1_path](https://runescape.wiki/images/Balloon_castle_wars_1_path.png)
![Balloon_castle_wars_2_path](https://runescape.wiki/images/Balloon_castle_wars_2_path.png)
![Balloon_castle_wars_3_path](https://runescape.wiki/images/Balloon_castle_wars_3_path.png)

### Balloon crafting guild path

![Balloon_crafting_guild_1_path](https://runescape.wiki/images/Balloon_crafting_guild_1_path.png)
![Balloon_crafting_guild_2_path](https://runescape.wiki/images/Balloon_crafting_guild_2_path.png)
![Balloon_crafting_guild_3_path](https://runescape.wiki/images/Balloon_crafting_guild_3_path.png)

### Balloon grand tree path

![Balloon_grand_tree_1_path](https://runescape.wiki/images/Balloon_grand_tree_1_path.png)
![Balloon_grand_tree_2_path](https://runescape.wiki/images/Balloon_grand_tree_2_path.png)
![Balloon_grand_tree_3_path](https://runescape.wiki/images/Balloon_grand_tree_3_path.png)

### Balloon taverley path

![Balloon_taverley_1_path](https://runescape.wiki/images/archive/20111117181727%21Balloon_taverley_1_path.png?00436)
![Balloon_taverley_2_path](https://runescape.wiki/images/archive/20111117181803%21Balloon_taverley_2_path.png?088c1)
![Balloon_taverley_3_path](https://runescape.wiki/images/archive/20111117181839%21Balloon_taverley_3_path.png?4e9ac)

### Balloon varrock path

![Balloon_varrock_1_path](https://runescape.wiki/images/Balloon_varrock_1_path.png?15cea&20221010084015)
![Balloon_varrock_2_path](https://runescape.wiki/images/Balloon_varrock_2_path.png?27ed2&20221010083955)
![Balloon_varrock_3_path](https://runescape.wiki/images/Balloon_varrock_3_path.png?c0427&20221010083410)

### Advisor system

![advisor_system](https://runescape.wiki/images/archive/20091021201906%21Advisor_system.png?fc54c)

### 2009 Christmas event reward scrolls

![2009_Christmas_event_reward](https://runescape.wiki/images/2009_Christmas_event_reward.png?50fc2)

### Quest reward scrolls

![q](https://i.imgur.com/xrX3ig7.png)
![q](https://i.imgur.com/HVz4L63.gif)
![q](https://i.imgur.com/sQ6RK9J.gif)
![q](https://i.imgur.com/hGWaJUK.gif)
![q](https://i.imgur.com/D6HIPUB.gif)
![q](https://i.imgur.com/EL39KdR.gif)
![q](https://i.imgur.com/TNY8d4q.gif)
![q](https://i.imgur.com/2GRNFtf.gif)
![q](https://i.imgur.com/39wPOAI.gif)
![q](https://i.imgur.com/hlCbedg.png)
![q](https://i.imgur.com/t6RKSLd.gif)
![q](https://i.imgur.com/2dZp01F.gif)
![q](https://i.imgur.com/DBM55mK.gif)
![q](https://i.imgur.com/lAuhekq.gif)
![q](https://i.imgur.com/dBGWCyd.gif)
![q](https://i.imgur.com/5NBtPZW.gif)
![q](https://i.imgur.com/5od2Ipn.gif)
![q](https://i.imgur.com/nsQZJwG.gif)
![q](https://i.imgur.com/zupTCti.gif)
![q](https://i.imgur.com/p0PJq7Z.gif)
![q](https://i.imgur.com/sOFhvaY.gif)
![q](https://i.imgur.com/eqAggqp.gif)
![q](https://i.imgur.com/6Ix2Fqs.gif)
![q](https://i.imgur.com/ydwGaVY.gif)
![q](https://i.imgur.com/sW6URxy.gif)
![q](https://i.imgur.com/5ZuIvj5.gif)
![q](https://i.imgur.com/Nc5auh7.gif)
![q](https://i.imgur.com/Idiv9JK.gif)
![q](https://i.imgur.com/CXA5Twp.gif)
![q](https://i.imgur.com/alcX8h1.gif)
![q](https://i.imgur.com/jws7Br1.gif)
![q](https://i.imgur.com/Y25BCmh.gif)
![q](https://i.imgur.com/SQtFvVz.gif)
![q](https://i.imgur.com/VF1WGoo.gif)
![q](https://i.imgur.com/m36h9HT.gif)
![q](https://i.imgur.com/feYvlRp.gif)
![q](https://i.imgur.com/E7lFweR.gif)
![q](https://i.imgur.com/zFdFWX7.gif)
![q](https://i.imgur.com/KGLz5si.gif)
![q](https://i.imgur.com/4nZQjXn.gif)
![q](https://i.imgur.com/alyu4uV.gif)
![q](https://i.imgur.com/Ziy7kwj.gif)
![q](https://i.imgur.com/9PsvbvW.gif)
![q](https://i.imgur.com/gmQ4uzc.gif)
![q](https://i.imgur.com/7eLxUAR.gif)
![q](https://i.imgur.com/5NSNHpB.gif)
![q](https://i.imgur.com/5Tg76OG.gif)
![q](https://i.imgur.com/0ZZZhj8.gif)
![q](https://i.imgur.com/l3CsrCg.gif)
![q](https://i.imgur.com/20CiriA.gif)
![q](https://i.imgur.com/7RYWQaJ.gif)
![q](https://i.imgur.com/6o1EEgM.gif)
![q](https://i.imgur.com/JJYeGTP.gif)
![q](https://i.imgur.com/vQync6R.gif)
![q](https://i.imgur.com/49Eck96.gif)
![q](https://i.imgur.com/Qn8jWID.gif)
![q](https://i.imgur.com/f43EQYH.gif)
![q](https://i.imgur.com/NCyO1aN.gif)
![q](https://i.imgur.com/r7SzYv5.gif)
![q](https://i.imgur.com/1yEjQ95.gif)
![q](https://i.imgur.com/Rn778k8.gif)
![q](https://i.imgur.com/EYFA5tM.gif)
![q](https://i.imgur.com/CPry4RQ.gif)
![q](https://i.imgur.com/qrZrSKS.gif)
![q](https://i.imgur.com/080byI2.gif)
![q](https://i.imgur.com/2OOeHcE.gif)
![q](https://i.imgur.com/k62cYJT.gif)
![q](https://i.imgur.com/EbWGMVl.gif)
![q](https://i.imgur.com/FmabisL.gif)
![q](https://i.imgur.com/BZ5wySa.gif)
![q](https://i.imgur.com/xokhNwp.gif)
![q](https://i.imgur.com/bkouXVI.gif)